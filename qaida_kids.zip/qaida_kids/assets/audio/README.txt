Weka rekodi za mwalimu hapa (MP3).
  letter_<herufi>.mp3      -> jina la herufi, mfano letter_ba.mp3
  h_<herufi>_a.mp3         -> herufi na fathah
  h_<herufi>_i.mp3         -> herufi na kasrah
  h_<herufi>_u.mp3         -> herufi na dammah
  w_<herufi>.mp3, simba.mp3, mama.mp3 ... -> sauti za maneno
Kama faili halipo, hakuna sauti inayotoka (app haivunjiki).
