Weka picha zako hapa (PNG, mandharinyuma ya uwazi, takriban 512x512).
Kama picha haipo, app inaonyesha emoji badala yake.

Majina ya faili:
  w_<herufi>.png   -> picha ya neno la herufi, mfano w_ba.png, w_ta.png
  <kitu>.png       -> wanyama na watu, mfano simba.png, mama.png
Angalia orodha kamili kwenye README.md
