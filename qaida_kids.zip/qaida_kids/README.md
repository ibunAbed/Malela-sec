# Qaidah Nuraniyah kwa watoto (toleo la majaribio)

## Jinsi ya kupata APK kupitia GitHub
1. Tengeneza repository mpya kwenye GitHub (mfano `qaida-kids`).
2. Pakia faili zote za folda hii (pamoja na `.github`) kwenye repository, tawi la `main`.
3. Nenda **Actions** > **Build APK** > subiri ikamilike (dakika 5-10).
4. Fungua build ya mwisho, chini ya **Artifacts** pakua `qaida-apk`, kisha usakinishe `app-release.apk` kwenye simu.
Ukitaka kuendesha mwenyewe: Actions > Build APK > Run workflow.

## Kilicho tayari
- Skrini 8: Anza, Nyumbani, Herufi, Kadi ya herufi, Maneno (wanyama/watu), Mazoezi, Matokeo, Mipangilio.
- Ramani ya masomo 17 (somo la 1 na la 4 ndilo tayari; mengine yanasema "linakuja").
- Herufi 29 zenye maneno yaliyosahihishwa (kila neno linaanza na herufi yake).
- Harakat (fathah, kasrah, dammah) kwa herufi zote.

## Kuweka picha zako
Weka PNG kwenye `assets/images/`. Kama hakuna picha, app inaonyesha emoji.
- Herufi: `w_alif.png, w_ba.png, w_ta.png, w_tha.png, w_jim.png, w_ha.png, w_kha.png, w_dal.png, w_dhal.png, w_ra.png, w_zay.png, w_sin.png, w_shin.png, w_sad.png, w_dad.png, w_tta.png, w_zha.png, w_ayn.png, w_ghayn.png, w_fa.png, w_qaf.png, w_kaf.png, w_lam.png, w_mim.png, w_nun.png, w_haa.png, w_waw.png, w_ya.png, w_hamza.png`
- Wanyama: `simba, tembo, ngombe, mbwa, kuku, paka, ndege, twiga`
- Watu: `mvulana, msichana, baba, mama, mzee, daktari, mwalimu, polisi, mkulima`

## Kuweka sauti za mwalimu
Weka MP3 kwenye `assets/audio/` (rekodi ya mwalimu mwenye sifa, si sauti ya kompyuta):
- `letter_<id>.mp3` (jina la herufi), `h_<id>_a.mp3`, `h_<id>_i.mp3`, `h_<id>_u.mp3`
- `w_<id>.mp3` (neno la herufi), na majina ya wanyama/watu kama hapo juu.
Faili likikosekana, hakuna sauti na app haivunjiki.

## Hatua zinazofuata
Masomo 2, 3 na 5 hadi 17, kuhifadhi alama kwenye simu, wahusika wanaosogea (Rive/Lottie).
