/// Data ya app: herufi, wanyama, watu na orodha ya masomo.
/// Maneno ya herufi yamesahihishwa ili kila neno lianze na herufi yake.

class Letter {
  final String id, ar, name, stem, wordAr, wordSw, emoji;
  const Letter(this.id, this.ar, this.name, this.stem, this.wordAr,
      this.wordSw, this.emoji);
}

class Item {
  final String id, ar, sw, emoji;
  const Item(this.id, this.ar, this.sw, this.emoji);
}

class Lesson {
  final String ar, sw;
  const Lesson(this.ar, this.sw);
}

const letters = <Letter>[
  Letter('alif', 'ا', 'Alif', '', 'أرنب', 'Sungura', '🐰'),
  Letter('ba', 'ب', 'Baa', 'b', 'بطة', 'Bata', '🦆'),
  Letter('ta', 'ت', 'Taa', 't', 'تمر', 'Tende', '🌴'),
  Letter('tha', 'ث', 'Thaa', 'th', 'ثعلب', 'Mbweha', '🦊'),
  Letter('jim', 'ج', 'Jiim', 'j', 'جمل', 'Ngamia', '🐪'),
  Letter('ha', 'ح', 'Ḥaa', 'ḥ', 'حصان', 'Farasi', '🐴'),
  Letter('kha', 'خ', 'Khaa', 'kh', 'خروف', 'Kondoo', '🐑'),
  Letter('dal', 'د', 'Daal', 'd', 'دجاجة', 'Kuku', '🐔'),
  Letter('dhal', 'ذ', 'Dhaal', 'dh', 'ذئب', 'Mbwa mwitu', '🐺'),
  Letter('ra', 'ر', 'Raa', 'r', 'رمان', 'Komamanga', '🍎'),
  Letter('zay', 'ز', 'Zaay', 'z', 'زرافة', 'Twiga', '🦒'),
  Letter('sin', 'س', 'Siin', 's', 'سمكة', 'Samaki', '🐟'),
  Letter('shin', 'ش', 'Shiin', 'sh', 'شمس', 'Jua', '☀️'),
  Letter('sad', 'ص', 'Ṣaad', 'ṣ', 'صقر', 'Kipanga', '🦅'),
  Letter('dad', 'ض', 'Ḍaad', 'ḍ', 'ضفدع', 'Chura', '🐸'),
  Letter('tta', 'ط', 'Ṭaa', 'ṭ', 'طائر', 'Ndege', '🐦'),
  Letter('zha', 'ظ', 'Ẓaa', 'ẓ', 'ظرف', 'Bahasha', '✉️'),
  Letter('ayn', 'ع', 'Ayn', 'ʿ', 'عنب', 'Zabibu', '🍇'),
  Letter('ghayn', 'غ', 'Ghayn', 'gh', 'غيمة', 'Wingu', '☁️'),
  Letter('fa', 'ف', 'Faa', 'f', 'فيل', 'Tembo', '🐘'),
  Letter('qaf', 'ق', 'Qaaf', 'q', 'قطة', 'Paka', '🐱'),
  Letter('kaf', 'ك', 'Kaaf', 'k', 'كتاب', 'Kitabu', '📘'),
  Letter('lam', 'ل', 'Laam', 'l', 'ليمون', 'Limau', '🍋'),
  Letter('mim', 'م', 'Miim', 'm', 'مسجد', 'Msikiti', '🕌'),
  Letter('nun', 'ن', 'Nuun', 'n', 'نحلة', 'Nyuki', '🐝'),
  Letter('haa', 'ه', 'Haa', 'h', 'هلال', 'Mwezi mwandamo', '🌙'),
  Letter('waw', 'و', 'Waaw', 'w', 'وردة', 'Ua', '🌹'),
  Letter('ya', 'ي', 'Yaa', 'y', 'يد', 'Mkono', '✋'),
  Letter('hamza', 'ء', 'Hamza', '', 'أسد', 'Simba', '🦁'),
];

const animals = <Item>[
  Item('simba', 'أسد', 'Simba', '🦁'),
  Item('tembo', 'فيل', 'Tembo', '🐘'),
  Item('ngombe', 'بقرة', "Ng'ombe", '🐄'),
  Item('mbwa', 'كلب', 'Mbwa', '🐕'),
  Item('kuku', 'دجاجة', 'Kuku', '🐔'),
  Item('paka', 'قطة', 'Paka', '🐱'),
  Item('ndege', 'طير', 'Ndege', '🐦'),
  Item('twiga', 'زرافة', 'Twiga', '🦒'),
];

const people = <Item>[
  Item('mvulana', 'ولد', 'Mvulana', '👦'),
  Item('msichana', 'بنت', 'Msichana', '👧'),
  Item('baba', 'أب', 'Baba', '👨'),
  Item('mama', 'أم', 'Mama', '👩'),
  Item('mzee', 'شيخ', 'Mzee', '👴'),
  Item('daktari', 'طبيب', 'Daktari', '🧑‍⚕️'),
  Item('mwalimu', 'معلم', 'Mwalimu', '🧑‍🏫'),
  Item('polisi', 'شرطي', 'Polisi', '👮'),
  Item('mkulima', 'فلاح', 'Mkulima', '🧑‍🌾'),
];

/// Masomo 17 ya Qaida. Masomo yaliyo tayari: 1 na 4 (mengine yanakuja).
const lessons = <Lesson>[
  Lesson('الحروف المفردة', 'Herufi moja moja'),
  Lesson('الحروف المركبة', 'Herufi zilizounganishwa'),
  Lesson('الحروف المقطعة', 'Herufi za mwanzo wa sura'),
  Lesson('الحروف المتحركة', 'Harakat: fathah, kasrah, dammah'),
  Lesson('الحروف المنونة', 'Tanwin'),
  Lesson('تدريبات على الحركات والتنوين', 'Mazoezi ya harakat na tanwin'),
  Lesson('الألف الصغيرة والياء والواو', 'Alif, yaa na waaw ndogo'),
  Lesson('حروف المد واللين', 'Herufi za madd na leen'),
  Lesson('تدريبات على التنوين وحروف المد', 'Mazoezi ya tanwin na madd'),
  Lesson('السكون', 'Sukun'),
  Lesson('تدريبات على السكون', 'Mazoezi ya sukun'),
  Lesson('الشدة', 'Shaddah'),
  Lesson('تدريبات على الشدة', 'Mazoezi ya shaddah'),
  Lesson('تدريبات على الشدة والسكون', 'Shaddah na sukun pamoja'),
  Lesson('تدريبات على الشدتين في كلمة', 'Shaddah mbili katika neno moja'),
  Lesson('تدريبات على المد مع الشدة', 'Madd pamoja na shaddah'),
  Lesson('الدرس الأخير', 'Somo la mwisho'),
];

/// Masomo yaliyo tayari kutumika (nambari kuanzia 1).
const readyLessons = <int>{1, 4};
