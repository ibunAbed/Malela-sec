import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

const kGreen = Color(0xFF14724A);
const kCream = Color(0xFFFFF6DC);
const kGold = Color(0xFFF5A623);

const pastel = <Color>[
  Color(0xFFFFF1CC),
  Color(0xFFD9ECFF),
  Color(0xFFE3F3D3),
  Color(0xFFEBDDF7),
  Color(0xFFFFE4D1),
];

void go(BuildContext context, Widget page) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => page));
}

/// Sauti: inacheza rekodi ya mwalimu kutoka assets/audio/<id>.mp3.
/// Faili likikosekana, hakuna kinachotokea.
class Sound {
  static bool enabled = true;
  static final AudioPlayer _player = AudioPlayer();

  static Future<void> play(String id) async {
    if (!enabled) return;
    try {
      await _player.stop();
      await _player.play(AssetSource('audio/$id.mp3'));
    } catch (_) {}
  }
}

/// Matokeo ya mazoezi (yanakaa kwenye kumbukumbu wakati app inaendelea).
class Stats {
  static int best = 0;
  static int total = 10;
  static int played = 0;

  static void update(int score, int outOf) {
    played++;
    if (score >= best) {
      best = score;
      total = outOf;
    }
  }
}

/// Picha kutoka assets/images/<id>.png; ikikosekana, inaonyesha emoji.
class Pic extends StatelessWidget {
  final String id, emoji;
  final double size;
  const Pic(this.id, this.emoji, {super.key, this.size = 56});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        'assets/images/$id.png',
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => FittedBox(
          fit: BoxFit.contain,
          child: Text(emoji, style: const TextStyle(fontSize: 100)),
        ),
      ),
    );
  }
}

class BigButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final Color color;
  final Color textColor;
  const BigButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.color = kGreen,
    this.textColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: FilledButton(
        onPressed: onTap,
        style: FilledButton.styleFrom(
          backgroundColor: color,
          foregroundColor: textColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label),
            if (icon != null) ...[
              const SizedBox(width: 8),
              Icon(icon, size: 22),
            ],
          ],
        ),
      ),
    );
  }
}
