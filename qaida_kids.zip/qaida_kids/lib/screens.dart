import 'dart:math';
import 'package:flutter/material.dart';
import 'data.dart';
import 'widgets.dart';

// ---------------------------------------------------------------- Anza

class StartScreen extends StatelessWidget {
  const StartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFBFE8FF), Color(0xFFE9F7D9), Color(0xFF8FD07A)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 24),
                const Text(
                  'Qaidah\nNuraniyah',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 44,
                      fontWeight: FontWeight.w800,
                      color: kGreen,
                      height: 1.1),
                ),
                const SizedBox(height: 12),
                const Text(
                  "Jifunze Kiswahili, Kiarabu na Qur'ani kwa urahisi",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18, color: Color(0xFF244D3A)),
                ),
                const Spacer(),
                const Text('🕌', style: TextStyle(fontSize: 90)),
                const Text('👦👧', style: TextStyle(fontSize: 96)),
                const Spacer(),
                BigButton(
                  label: 'Anza',
                  icon: Icons.arrow_forward,
                  onTap: () => go(context, const HomeScreen()),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Nyumbani

class _Tile {
  final String label;
  final IconData icon;
  final Color color;
  final Widget page;
  const _Tile(this.label, this.icon, this.color, this.page);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tiles = <_Tile>[
      const _Tile('Herufi za Kiarabu', Icons.menu_book, Color(0xFF4CAF50),
          LettersScreen()),
      const _Tile('Maneno na Sentensi', Icons.auto_stories, Color(0xFF2196F3),
          WordsScreen()),
      const _Tile('Sauti za Kiarabu', Icons.volume_up, Color(0xFFFFA000),
          HarakatScreen()),
      const _Tile('Mazoezi na Michezo', Icons.sports_esports,
          Color(0xFF7E57C2), QuizScreen()),
      const _Tile('Matokeo', Icons.star, Color(0xFFEF5350), ScoreScreen()),
      const _Tile('Mipangilio', Icons.settings, Color(0xFF00897B),
          SettingsScreen()),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Qaidah Nuraniyah')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: kCream,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                const Text('👦', style: TextStyle(fontSize: 64)),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
                          style: TextStyle(fontSize: 22, color: kGreen)),
                      SizedBox(height: 6),
                      Text('Jifunze kwa hamu, fikia malengo yako.',
                          style: TextStyle(fontSize: 16)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          BigButton(
            label: 'Masomo ya Qaida',
            icon: Icons.route,
            color: kGold,
            textColor: const Color(0xFF3A2A00),
            onTap: () => go(context, const LessonsScreen()),
          ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.2,
            children: [
              for (final t in tiles)
                Material(
                  color: t.color,
                  borderRadius: BorderRadius.circular(18),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => go(context, t.page),
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(t.icon, color: Colors.white, size: 40),
                          const SizedBox(height: 8),
                          Text(t.label,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- Ramani ya masomo

class LessonsScreen extends StatelessWidget {
  const LessonsScreen({super.key});

  void _open(BuildContext context, int n) {
    if (n == 1) {
      go(context, const LettersScreen());
    } else if (n == 4) {
      go(context, const HarakatScreen());
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Somo hili linakuja hivi karibuni.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Masomo ya Qaida')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: lessons.length,
        itemBuilder: (context, i) {
          final n = i + 1;
          final ready = readyLessons.contains(n);
          final l = lessons[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Material(
              color: ready ? pastel[i % pastel.length] : const Color(0xFFEDEDED),
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => _open(context, n),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: ready ? kGreen : Colors.grey,
                        foregroundColor: Colors.white,
                        child: Text('$n'),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(l.sw,
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.w700)),
                            const SizedBox(height: 2),
                            Text(l.ar,
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black54)),
                          ],
                        ),
                      ),
                      Icon(ready ? Icons.chevron_right : Icons.lock_outline,
                          color: ready ? Colors.black87 : Colors.grey),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------- Herufi

class LettersScreen extends StatelessWidget {
  const LettersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Herufi za Kiarabu')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: letters.length,
        itemBuilder: (context, i) {
          final l = letters[i];
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Material(
              color: pastel[i % pastel.length],
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => go(context, LetterDetailScreen(index: i)),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 70,
                        child: Text(l.ar,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 44, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(l.name,
                            style: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w600)),
                      ),
                      Pic('w_${l.id}', l.emoji, size: 52),
                      const SizedBox(width: 6),
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class LetterDetailScreen extends StatelessWidget {
  final int index;
  const LetterDetailScreen({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    final l = letters[index];
    final last = index == letters.length - 1;
    return Scaffold(
      appBar: AppBar(title: Text('Herufi: ${l.ar} (${l.name})')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Sound.play('letter_${l.id}'),
                      child: FittedBox(
                        fit: BoxFit.contain,
                        child: Text(l.ar,
                            style: const TextStyle(
                                fontSize: 160, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ),
                  Pic('w_${l.id}', l.emoji, size: 110),
                ],
              ),
            ),
            Text(l.name,
                style:
                    const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              elevation: 1,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => Sound.play('letter_${l.id}'),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: kGreen,
                        foregroundColor: Colors.white,
                        child: Icon(Icons.volume_up),
                      ),
                      const SizedBox(width: 12),
                      Text('Sauti: ${l.name}',
                          style: const TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            InkWell(
              onTap: () => Sound.play('w_${l.id}'),
              borderRadius: BorderRadius.circular(16),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: kCream,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    Text('Neno lenye ${l.name}',
                        style: const TextStyle(fontSize: 14)),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Pic('w_${l.id}', l.emoji, size: 48),
                        const SizedBox(width: 12),
                        Text(l.wordAr,
                            style: const TextStyle(
                                fontSize: 34, fontWeight: FontWeight.bold)),
                        const SizedBox(width: 10),
                        Flexible(
                          child: Text('(${l.wordSw})',
                              style: const TextStyle(fontSize: 18)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            BigButton(
              label: last ? 'Maliza' : 'Endelea',
              icon: Icons.arrow_forward,
              onTap: () {
                if (last) {
                  Navigator.pop(context);
                } else {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (_) => LetterDetailScreen(index: index + 1)),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Harakat (Somo la 4)

class HarakatScreen extends StatefulWidget {
  const HarakatScreen({super.key});

  @override
  State<HarakatScreen> createState() => _HarakatScreenState();
}

class _HarakatScreenState extends State<HarakatScreen> {
  int sel = 1; // anza na Baa

  // [alama, irabu, jina]
  static const marks = <List<String>>[
    ['\u064E', 'a', 'Fathah'],
    ['\u0650', 'i', 'Kasrah'],
    ['\u064F', 'u', 'Dammah'],
  ];

  @override
  Widget build(BuildContext context) {
    final l = letters[sel];
    final base = l.ar == 'ا' ? 'أ' : l.ar;
    return Scaffold(
      appBar: AppBar(title: const Text('Harakat')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: kCream,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Text(
              'Fathah = a, Kasrah = i, Dammah = u.\n'
              'Chagua herufi, kisha bonyeza kadi usikie sauti.',
              style: TextStyle(fontSize: 16),
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            textDirection: TextDirection.rtl,
            children: [
              for (var i = 0; i < letters.length; i++)
                ChoiceChip(
                  label: Text(letters[i].ar,
                      style: const TextStyle(fontSize: 24)),
                  selected: sel == i,
                  selectedColor: const Color(0xFFBFE3CF),
                  onSelected: (_) => setState(() => sel = i),
                ),
            ],
          ),
          const SizedBox(height: 18),
          Text(l.name,
              textAlign: TextAlign.center,
              style:
                  const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Row(
            children: [
              for (var m = 0; m < marks.length; m++)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: m == 0 ? 0 : 8),
                    child: Material(
                      color: pastel[m],
                      borderRadius: BorderRadius.circular(16),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => Sound.play('h_${l.id}_${marks[m][1]}'),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          child: Column(
                            children: [
                              Text('$base${marks[m][0]}',
                                  style: const TextStyle(
                                      fontSize: 64,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 6),
                              Text('${l.stem}${marks[m][1]}',
                                  style: const TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.w700)),
                              Text(marks[m][2],
                                  style: const TextStyle(fontSize: 14)),
                              const SizedBox(height: 6),
                              const Icon(Icons.volume_up, color: kGreen),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed:
                      sel > 0 ? () => setState(() => sel--) : null,
                  child: const Text('Iliyotangulia'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: sel < letters.length - 1
                      ? () => setState(() => sel++)
                      : null,
                  style: FilledButton.styleFrom(backgroundColor: kGreen),
                  child: const Text('Inayofuata'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- Maneno

class WordsScreen extends StatelessWidget {
  const WordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Maneno'),
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [Tab(text: 'Wanyama'), Tab(text: 'Watu')],
          ),
        ),
        body: const TabBarView(
          children: [_ItemGrid(animals), _ItemGrid(people)],
        ),
      ),
    );
  }
}

class _ItemGrid extends StatelessWidget {
  final List<Item> items;
  const _ItemGrid(this.items);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.05,
      ),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final it = items[i];
        return Material(
          color: pastel[i % pastel.length],
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => Sound.play(it.id),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Pic(it.id, it.emoji, size: 72),
                  const SizedBox(height: 6),
                  Text(it.sw,
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                  Text(it.ar, style: const TextStyle(fontSize: 20)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------- Mazoezi

class _Q {
  final Item item;
  final List<String> options;
  _Q(this.item, this.options);
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final List<_Q> qs;
  int cur = 0;
  int score = 0;
  String? picked;

  @override
  void initState() {
    super.initState();
    qs = _build();
  }

  List<_Q> _build() {
    final rnd = Random();
    final bySw = <String, Item>{};
    for (final l in letters) {
      bySw[l.wordSw] = Item('w_${l.id}', l.wordAr, l.wordSw, l.emoji);
    }
    for (final a in animals) {
      bySw[a.sw] = a;
    }
    for (final p in people) {
      bySw[p.sw] = p;
    }
    final pool = bySw.values.toList()..shuffle(rnd);
    final picks = pool.take(10).toList();
    return [
      for (final it in picks)
        () {
          final others = pool.where((x) => x.sw != it.sw).toList()
            ..shuffle(rnd);
          final opts = [it.sw, ...others.take(3).map((x) => x.sw)]
            ..shuffle(rnd);
          return _Q(it, opts);
        }(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final q = qs[cur];
    final answered = picked != null;
    return Scaffold(
      appBar: AppBar(title: const Text('Mazoezi')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Swali ${cur + 1} / ${qs.length}',
                style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 6),
            LinearProgressIndicator(
              value: (cur + 1) / qs.length,
              minHeight: 8,
              borderRadius: BorderRadius.circular(8),
              color: kGreen,
            ),
            const SizedBox(height: 16),
            const Text('Chagua jina sahihi la picha.',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: kCream,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Pic(q.item.id, q.item.emoji, size: 130),
                  const SizedBox(height: 4),
                  Text(q.item.ar, style: const TextStyle(fontSize: 26)),
                ],
              ),
            ),
            const SizedBox(height: 14),
            for (final o in q.options)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: !answered
                      ? Colors.white
                      : o == q.item.sw
                          ? const Color(0xFFD6F2DF)
                          : o == picked
                              ? const Color(0xFFFFD9D9)
                              : Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: answered
                        ? null
                        : () => setState(() {
                              picked = o;
                              if (o == q.item.sw) score++;
                            }),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFFD8D8D8)),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                              child: Text(o,
                                  style: const TextStyle(fontSize: 18))),
                          if (answered && o == q.item.sw)
                            const Icon(Icons.check_circle, color: kGreen),
                          if (answered && o == picked && o != q.item.sw)
                            const Icon(Icons.cancel, color: Colors.redAccent),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            const Spacer(),
            BigButton(
              label: cur == qs.length - 1 ? 'Maliza' : 'Endelea',
              icon: Icons.arrow_forward,
              onTap: !answered
                  ? null
                  : () {
                      if (cur == qs.length - 1) {
                        Stats.update(score, qs.length);
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  ResultScreen(score: score, total: qs.length)),
                        );
                      } else {
                        setState(() {
                          cur++;
                          picked = null;
                        });
                      }
                    },
            ),
          ],
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score, total;
  const ResultScreen({super.key, required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFBFE8FF), Color(0xFF8FD07A)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Spacer(),
                const Text('🏆', style: TextStyle(fontSize: 110)),
                const Text('Hongera!',
                    style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                        color: kGreen)),
                const SizedBox(height: 6),
                Text(score >= total * 0.7
                    ? 'Umejifunza vizuri'
                    : 'Endelea kujaribu, utaweza'),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.star, color: kGold, size: 40),
                      const SizedBox(width: 10),
                      Text('Alama: $score / $total',
                          style: const TextStyle(
                              fontSize: 26, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                const Spacer(),
                BigButton(
                  label: 'Endelea',
                  icon: Icons.arrow_forward,
                  onTap: () => Navigator.of(context)
                      .popUntil((route) => route.isFirst),
                ),
                const SizedBox(height: 10),
                BigButton(
                  label: 'Rudia',
                  color: const Color(0xFFE3F3D3),
                  textColor: kGreen,
                  onTap: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const QuizScreen()),
                  ),
                ),
                const SizedBox(height: 10),
                const Text('Elimu ni nuru ya maisha',
                    style: TextStyle(fontSize: 16)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Matokeo na Mipangilio

class ScoreScreen extends StatelessWidget {
  const ScoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Matokeo')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.star, color: kGold, size: 90),
              const SizedBox(height: 12),
              Text(
                Stats.played == 0
                    ? 'Bado hujafanya mazoezi.'
                    : 'Alama bora: ${Stats.best} / ${Stats.total}',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text('Mazoezi yaliyofanywa: ${Stats.played}',
                  style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 20),
              if (Stats.played == 0)
                BigButton(
                  label: 'Anza mazoezi',
                  icon: Icons.arrow_forward,
                  onTap: () => go(context, const QuizScreen()),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mipangilio')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Sauti'),
            subtitle: const Text('Washa au zima sauti za mwalimu'),
            value: Sound.enabled,
            activeColor: kGreen,
            onChanged: (v) => setState(() => Sound.enabled = v),
          ),
        ],
      ),
    );
  }
}
